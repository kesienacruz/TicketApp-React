import React from "react";
import { Link } from "react-router-dom";
import heroWave from "../assets/hero-wave.svg";
import circleLg from "../assets/circle-lg.svg";
import circleSm from "../assets/circle-sm.svg";

export default function Landing(){
  return (
    <div className="min-h-screen flex flex-col bg-surface-subtle text-text">
      <section className="relative bg-surface-subtle text-text overflow-hidden">
        <img
          src={heroWave}
          alt=""
          aria-hidden="true"
          className="absolute inset-x-0 top-0 w-full max-w-screen1440 mx-auto pointer-events-none select-none"
        />
        <img
          src={circleLg}
          alt=""
          aria-hidden="true"
          className="pointer-events-none select-none absolute -top-28 -left-28 w-[260px] blur-2xl opacity-60 md:w-[320px] md:-top-32 md:-left-32"
        />
        <img
          src={circleSm}
          alt=""
          aria-hidden="true"
          className="pointer-events-none select-none absolute top-16 right-4 w-24 blur-xl opacity-80 md:w-32 md:top-20 md:right-12"
        />

        <div className="relative page-shell py-24 md:py-32">
          <div className="max-w-xl space-y-6 relative">
            <h1 className="text-display-xl text-text font-semibold">
              Track, resolve, and celebrate every ticket.
            </h1>

            <p className="text-body-md text-text-dim max-w-md">
              A simple, consistent ticket manager built for teams. Works anywhere. No backend required.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <Link
                to="/auth/signup"
                className="inline-flex items-center justify-center rounded-pill bg-brand-600 px-5 py-3 text-white text-sm font-medium hover:bg-brand-700 focus-visible:ring-2 focus-visible:ring-brand-500"
              >
                Get Started
              </Link>

              <Link
                to="/auth/login"
                className="inline-flex items-center justify-center rounded-pill bg-surface px-5 py-3 text-sm font-medium text-text border border-surface-border hover:bg-surface-subtle focus-visible:ring-2 focus-visible:ring-brand-500"
              >
                Login
              </Link>
            </div>

            <div className="text-body-xs text-text-dim text-[12px] leading-[16px]">
              Test login: test@ticketapp.test / password123
            </div>
          </div>
        </div>

        <div className="h-px w-full bg-surface-border/60" />
      </section>

      <section className="page-shell py-12 grid gap-6 md:grid-cols-3">
        <div className="card p-4">
          <h2 className="text-title-sm font-semibold text-text mb-1">
            Stay organized
          </h2>
          <p className="text-body-sm text-text-dim">
            Tickets live in one place with real-time status badges.
          </p>
        </div>

        <div className="card p-4">
          <h2 className="text-title-sm font-semibold text-text mb-1">
            Move fast
          </h2>
          <p className="text-body-sm text-text-dim">
            Create, edit, and resolve with instant feedback.
          </p>
        </div>

        <div className="card p-4">
          <h2 className="text-title-sm font-semibold text-text mb-1">
            Accessible by design
          </h2>
          <p className="text-body-sm text-text-dim">
            Keyboard-friendly, screen-reader aware, responsive layout.
          </p>
        </div>
      </section>

      <footer className="border-t border-surface-border bg-surface py-4 text-center text-body-xs text-text-dim">
        <div className="page-shell">
          © 2025 TicketApp — All rights reserved.
        </div>
      </footer>
    </div>
  );
}
